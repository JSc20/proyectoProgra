package ET;

public class Branch {
    private int idBranch;
    private String nameBranch;
    private String locationBranch;
    
    public Branch(){    
    }
    public Branch(String nameBranch, String locationBranch,int idBranch){    
        this.idBranch=idBranch;
        this.nameBranch=nameBranch;
        this.locationBranch=locationBranch;
    }

    public int getIdBranch() {
        return idBranch;
    }

    public void setIdBranch(int idBranch) {
        this.idBranch = idBranch;
    }

    public String getNameBranch() {
        return nameBranch;
    }

    public void setNameBranch(String nameBranch) {
        this.nameBranch = nameBranch;
    }

    public String getLocationBranch() {
        return locationBranch;
    }

    public void setLocationBranch(String locationBranch) {
        this.locationBranch = locationBranch;
    }
    
    
}
