package ET;

public class Loan {
    
}
