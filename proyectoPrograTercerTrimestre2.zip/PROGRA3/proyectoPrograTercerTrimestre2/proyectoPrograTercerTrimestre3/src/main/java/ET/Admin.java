package ET;
public class Admin {
    
}
