package ET;
public class Person {
    protected String name;
    protected String firstLastName;
    protected String secondLastName;
    protected String socialNumber;
    protected String mail;
    protected String phoneNumber;

    public Person() {
    }

    public Person(String name, String firstLastName, String secondLastName, String socialNumber, String mail, String phoneNumber) {
        this.name = name;
        this.firstLastName = firstLastName;
        this.secondLastName = secondLastName;
        this.socialNumber = socialNumber;
        this.mail = mail;
        this.phoneNumber = phoneNumber;
    }
    
}
