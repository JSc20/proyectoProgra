package ET;
public class Customer extends Person {
    
    private int idCustomer;

    public Customer() {
    }

    public Customer(String name, String firstLastName, String secondLastName, String socialNumber, String mail, String phoneNumber) {
        super(name, firstLastName, secondLastName, socialNumber, mail, phoneNumber);
        this.idCustomer=idCustomer;
    }

    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        this.idCustomer = idCustomer;
    }
    
    
}
